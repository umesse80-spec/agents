// ==========================================================
// AGENTS_IA — CONTRÔLE DE LA SURVEILLANCE DE L'ONGLET MAIL
// Lance / arrête gmailMonitorWorker.js dans un processus séparé.
// Les automatisations utilisent Gmail directement depuis le
// serveur : elles continuent de fonctionner quand on arrête ici.
// ==========================================================

const fs = require("fs");
const path = require("path");
const { fork } = require("child_process");

const DATA_DIR = path.join(__dirname, "data");
const STATE_FILE = path.join(DATA_DIR, "gmail-monitor.json");
const WORKER = path.join(__dirname, "gmailMonitorWorker.js");

let child = null;
let interval = 60_000;
let restartTimer = null;
let restartDelay = 30_000;
let startedAt = null;
let lastError = null;
let stopping = false;

function loadState() {
    try {
        return JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
    } catch {
        // Par défaut : la surveillance tourne, comme avant
        return { enabled: true, changedAt: null };
    }
}

let state = loadState();

function saveState() {
    if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), "utf8");
}

function forward(stream, target) {
    stream.on("data", chunk => {
        const text = chunk.toString();
        target.write(text);
        const lines = text.trim().split("\n").filter(Boolean);
        const errorLine = lines.reverse().find(line => /erreur|error|impossible/i.test(line));
        if (errorLine) lastError = errorLine.trim().slice(0, 300);
    });
}

function spawnWorker() {
    clearTimeout(restartTimer);
    restartTimer = null;

    if (child) return;

    stopping = false;
    lastError = null;
    child = fork(WORKER, [String(interval)], { cwd: __dirname, silent: true });
    startedAt = new Date().toISOString();

    forward(child.stdout, process.stdout);
    forward(child.stderr, process.stderr);

    child.on("exit", code => {
        child = null;
        startedAt = null;

        if (stopping || !state.enabled) return;

        // Arrêt inattendu : nouvelle tentative avec un délai croissant
        lastError = lastError || `La surveillance s'est arrêtée (code ${code}).`;
        console.warn(`[MAIL] Surveillance arrêtée de façon inattendue. Nouvelle tentative dans ${restartDelay / 1000} s.`);
        restartTimer = setTimeout(spawnWorker, restartDelay);
        restartDelay = Math.min(restartDelay * 2, 5 * 60_000);
    });
}

function killWorker() {
    clearTimeout(restartTimer);
    restartTimer = null;
    if (!child) return;
    stopping = true;
    child.kill("SIGTERM");
}

function init(ms = 60_000) {
    interval = ms;
    if (state.enabled) spawnWorker();
    else console.log("[MAIL] Surveillance automatique de l'onglet Mail : arrêtée (bouton Stop)");
}

function start() {
    state = { enabled: true, changedAt: new Date().toISOString() };
    saveState();
    restartDelay = 30_000;
    spawnWorker();
    return status();
}

function stop() {
    state = { enabled: false, changedAt: new Date().toISOString() };
    saveState();
    killWorker();
    return status();
}

function status() {
    return {
        enabled: Boolean(state.enabled),
        running: Boolean(child) && !stopping,
        retrying: Boolean(restartTimer),
        startedAt,
        changedAt: state.changedAt,
        lastError,
        intervalSeconds: Math.round(interval / 1000)
    };
}

// Ne laisse pas de processus orphelin quand le serveur s'arrête
for (const signal of ["SIGINT", "SIGTERM"]) {
    process.on(signal, () => {
        killWorker();
        process.exit(0);
    });
}
process.on("exit", killWorker);

module.exports = { init, start, stop, status };
