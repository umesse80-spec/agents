// ==========================================================
// AGENTS_IA — PROCESSUS DE SURVEILLANCE DE L'ONGLET MAIL
// Ce petit programme tourne à côté du serveur. Il lance la
// surveillance automatique de ton agent Gmail (analyse des
// nouveaux e-mails, réponses automatiques de l'onglet Mail).
// L'arrêter n'a aucun effet sur les automatisations.
// ==========================================================

const interval = Number(process.argv[2]) || 60_000;

try {
    const gmailAgent = require("./agents/gmailAgent");

    if (typeof gmailAgent.startMonitoring !== "function") {
        throw new Error("agents/gmailAgent.js n'exporte pas startMonitoring().");
    }

    gmailAgent.startMonitoring(interval);
    console.log(`[MAIL] Surveillance automatique démarrée (toutes les ${Math.round(interval / 1000)} s)`);
} catch (error) {
    console.error("[MAIL] Impossible de démarrer la surveillance :", error.message);
    process.exit(1);
}

// Garde le processus en vie même si la surveillance utilise des minuteries détachées
setInterval(() => {}, 1 << 30);

// Arrêt propre quand le serveur demande l'arrêt
process.on("SIGTERM", () => process.exit(0));
process.on("disconnect", () => process.exit(0));
